data = load("SVdata.mat");
data.utterance;
% M1SET0 and M1SET1 spoken by a known speaker M1;
% M3SET0 and M3SET1 spoken by a known speaker M3
% X1S1T0 spoken by an unknown speaker X1
M1SET0 = data.utterance{1,1}
% M1SET1 = data.utterance{1,2};
% M3SET0 = data.utterance{1,3};
% M3SET1 = data.utterance{1,4};
% X1S1T0 = data.utterance{1,5};

% %% 1.a
% stle_E  = { [], [], [], [], []  };  % short-time log energy
% vp_VC   = { [], [], [], [], []  };  % voicing parameter
% 
% for signal_th = 1:5
%     % Calculate short-time log energy 𝐸𝑖 in dB
%     for i = 1:length(data.utterance{1,signal_th})
%         ret = 0;
%         if data.utterance{1,signal_th}(i) == 0
%             ret = 0;
%         else
%             % 20 is a common used scale 
%             ret = 20*log10(sqrt(abs(data.utterance{1,signal_th}(i))));
%         end
%         stle_E{signal_th}(i)= ret;
%     end
%     % Calculate short-time autocorrelation, or voicing parameter 𝑉𝐶𝑖 
%     vp_VC{signal_th} = xcorr(data.utterance{1,signal_th});
% end
% 
% 
% %% 1.b
% % Frame width [samples]: 
% frameWdth=256; 
% % Frame shift [samples]: 
% frameShft=128; 
% % Energy threshold [dB]: 
% eThr=-45; 
% % Voicing threshold: 
% vcThr=0.4;
% % Minimum fundamental frequency [Hz]: 
% f0Min=80; 
% % Maximum fundamental frequency [Hz]:
% f0Max=200;
% 
% 
% 
% 
% 
% 
% 
% % short-time log energy 𝐸𝑖 in dB
% M1SET0_e = [];
% for i = 1:length(M1SET0)
%     ret = 0;
%     if M1SET0(i) == 0
%         ret = 0;
%     else
%         ret = 20*log10(sqrt(abs(M1SET0(i))));
%     end
%     M1SET0_e(i) = ret;
% end
% % short-time autocorrelation, or voicing parameter 𝑉𝐶𝑖 
% M1SET0_vp = xcorr(M1SET0);